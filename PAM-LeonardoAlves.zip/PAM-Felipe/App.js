import React from 'react';
import { Image, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { Container, Texto, Img, Title} from './styles';

export default function App() {
  return (
    
    <Container>
      <Img source={{ uri: 'https://mh-1-agencia-estoque.panthermedia.net/media/media_detail/0011000000/11613000/11613119_detail.jpg' }} style={styles.logo} />
      <TouchableOpacity
        onPress={() => alert('O impossível é desculpa para o desistente e desafio para o vencedor!')}
        style={{ backgroundColor: 'lightblue'}}>
        <Texto id='teste'>Aperte para ver uma mensagem motivacional!</Texto>
      </TouchableOpacity>
    </Container>
    
  );
  

}



const styles = StyleSheet.create({
  logo: {
    width: 200,
    height: 200,
    marginBottom: 20,
  },

});

